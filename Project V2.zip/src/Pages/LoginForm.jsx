import React, { useEffect, useState } from "react";
import "./Styles/LoginForm.css";
import { useNavigate } from "react-router-dom";

function LoginForm() {
  const [role, setRole] = useState("");
  const [nextStep, setNextStep] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRoleChange = (event) => {
    setRole(event.target.value);
  };

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleNextStep = () => {
    setNextStep(role);
    localStorage.setItem("userRole", role);
    console.log(role)
    console.log(localStorage.getItem("userRole"))
  };

  useEffect(() => {
    if (nextStep === "Student") {
      navigate('/StudentDashboard');
    } else if (nextStep === "Supervisor") {
      navigate('/SuperDashboard');
    } else if (nextStep === "FYP Committee") {
      navigate('/CommitteeDashboard');
    }
  }, [nextStep, navigate]);

  return (
    <div>
      <form className="login-form">
        <h1>FYP Management System</h1>
        <label>Username:</label>
        <input
          type="text"
          value={username}
          onChange={handleUsernameChange}
        />
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={handlePasswordChange}
        />
        <label>Select Role:</label>
        <select value={role} onChange={handleRoleChange}>
          <option value="">Select</option>
          <option value="Student">Student</option>
          <option value="Supervisor">Supervisor</option>
          <option value="FYP Committee">FYP Committee</option>
        </select>
        <button type="button" onClick={handleNextStep}>
          Submit
        </button>
      </form>
    </div>
  );
}

export default LoginForm;
