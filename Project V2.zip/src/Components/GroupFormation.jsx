import React, { useState, useEffect } from "react";
import "./Styles/StudentList.css";

const GroupFormation = () => {
    const [groupNumber, setGroupNumber] = useState("");
    const [selectedStudent, setSelectedStudent] = useState("");
    const [selectedSupervisor, setSelectedSupervisor] = useState("");
    const [projectTitle, setProjectTitle] = useState("");
    const [students, setStudents] = useState([]);
    const [supervisors, setSupervisors] = useState([]);
    const [groups, setGroups] = useState([]);
    const [showGroups, setShowGroups] = useState(false);

    useEffect(() => {
        const storedGroups = localStorage.getItem("groups");
        if (storedGroups) {
            setGroups(JSON.parse(storedGroups));
        }
    }, []);

    useEffect(() => {
        const storedStudents = localStorage.getItem("students");
        if (storedStudents) {
            setStudents(JSON.parse(storedStudents));
        }
    }, []);

    useEffect(() => {
        const storedSupervisors = localStorage.getItem("supervisors");
        if (storedSupervisors) {
            setSupervisors(JSON.parse(storedSupervisors));
        }
    }, []);

    const handleAddToGroup = () => {
        if (selectedStudent && selectedSupervisor && groupNumber && projectTitle) {
            const student = students.find(
                (student) => student.rollNumber === selectedStudent
            );
            const supervisor = supervisors.find(
                (supervisor) => supervisor.id === selectedSupervisor
            );

            if (!student) {
                alert("Selected student does not exist.");
                return;
            }

            if (!supervisor) {
                alert("Selected supervisor does not exist.");
                return;
            }

            const existingGroup = groups.find((group) => group.number === groupNumber);

            if (existingGroup) {
                if (existingGroup.members.length >= 4) {
                    alert("Group already has maximum members (4).");
                    return;
                }
                const updatedGroups = groups.map((group) => {
                    if (group.number === groupNumber) {
                        return {
                            ...group,
                            members: [...group.members, student],
                        };
                    }
                    return group;
                });
                setGroups(updatedGroups);
                localStorage.setItem("groups", JSON.stringify(updatedGroups));
            } else {
                const newGroup = {
                    number: groupNumber,
                    members: [student],
                    supervisor: supervisor,
                    projectTitle: projectTitle,
                };
                const updatedGroups = [...groups, newGroup];
                setGroups(updatedGroups);
                localStorage.setItem("groups", JSON.stringify(updatedGroups));
            }

            setGroupNumber("");
            setSelectedStudent("");
            setSelectedSupervisor("");
            setProjectTitle("");
        } else {
            alert("Please select a student, supervisor, and enter a group number and project title.");
        }
    };

    const handleRemoveFromGroup = (groupNumber, studentRollNumber) => {
        const updatedGroups = groups.map((group) => {
            if (group.number === groupNumber) {
                group.members = group.members.filter(
                    (student) => student.rollNumber !== studentRollNumber
                );
            }
            return group;
        });
        setGroups(updatedGroups);
        localStorage.setItem("groups", JSON.stringify(updatedGroups));
    };

    const handleDeleteGroup = (groupNumber) => {
        const updatedGroups = groups.filter((group) => group.number !== groupNumber);
        setGroups(updatedGroups);
        localStorage.setItem("groups", JSON.stringify(updatedGroups));
    };

    const handleGroupNumberChange = (e) => {
        const value = e.target.value;
        if (/^\d*$/.test(value)) {
            setGroupNumber(value);
        }
    };

    const availableStudents = students.filter(
        (student) =>
            !groups.some((group) =>
                group.members.some((member) => member.rollNumber === student.rollNumber)
            )
    );

    return (
        <div>
            <h3>Add Student to Group</h3>
            <select
                value={selectedStudent}
                onChange={(e) => setSelectedStudent(e.target.value)}
            >
                <option value="" disabled>
                    Select Student
                </option>
                {availableStudents.map((student) => (
                    <option key={student.rollNumber} value={student.rollNumber}>
                        {student.name}
                    </option>
                ))}
            </select>
            <select
                value={selectedSupervisor}
                onChange={(e) => setSelectedSupervisor(e.target.value)}
            >
                <option value="" disabled>
                    Select Supervisor
                </option>
                {supervisors.map((supervisor) => (
                    <option key={supervisor.id} value={supervisor.id}>
                        {supervisor.name}
                    </option>
                ))}
            </select>
            <input
                type="text"
                placeholder="Group Number"
                value={groupNumber}
                onChange={handleGroupNumberChange}
                required
            />
            <input
                type="text"
                placeholder="Project Title"
                value={projectTitle}
                onChange={(e) => setProjectTitle(e.target.value)}
                required
            />
            <button onClick={handleAddToGroup}>Add to Group</button>

            <div className="group-list">
                <h2>Group List</h2>
                {groups.map((group, index) => (
                    <div key={index}>
                        <h3>Group {group.number}</h3>
                        <p><strong>Supervisor:</strong> {group.supervisor.name}</p>
                        <p><strong>Project Title:</strong> {group.projectTitle}</p>
                        <ul>
                            {group.members.map((student) => (
                                <li key={student.rollNumber}>
                                    {student.name} ({student.rollNumber})
                                    <button
                                        onClick={() =>
                                            handleRemoveFromGroup(group.number, student.rollNumber)
                                        }
                                    >
                                        Remove
                                    </button>
                                </li>
                            ))}
                        </ul>
                        <button onClick={() => handleDeleteGroup(group.number)}>
                            Delete Group
                        </button>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default GroupFormation