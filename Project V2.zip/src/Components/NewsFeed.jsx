import React, { useState, useEffect } from 'react';
import './Styles/NewsFeed.css'

const NewsFeed = () => {
  const [posts, setPosts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    const storedPosts = JSON.parse(localStorage.getItem('posts')) || [];
    setPosts(storedPosts);
  }, []);

  const handleShareClick = () => {
    setShowForm(true);
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const newPost = {
      title,
      description,
      date: new Date().toLocaleString(),
    };
    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    localStorage.setItem('posts', JSON.stringify(updatedPosts));
    setTitle('');
    setDescription('');
    setShowForm(false);
  };

  return (
    <div className="news-feed">
      <div className="header">
        <h2>Posts</h2>
        <button onClick={handleShareClick}>Share in Feed</button>
      </div>
      {showForm && (
        <form onSubmit={handleFormSubmit} className="post-form">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Title"
            required
          />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Description"
            required
          />
          <button type="submit">Submit</button>
        </form>
      )}
      <div className="posts">
        {posts.length > 0 ? (
          posts.map((post, index) => (
            <div key={index} className="post">
              <h3>{post.title}</h3>
              <p>{post.description}</p>
              <span>{post.date}</span>
            </div>
          ))
        ) : (
          <p>No posts yet.</p>
        )}
      </div>
    </div>
  );
};

export default NewsFeed;
