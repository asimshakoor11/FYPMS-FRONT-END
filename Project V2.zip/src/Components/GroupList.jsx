import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./Styles/GroupList.css";

function GroupList() {
  const [groups, setGroups] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const storedGroups = localStorage.getItem("groups");
    if (storedGroups) {
      setGroups(JSON.parse(storedGroups));
    }
  }, []);

  const handleGroupClick = (group) => {
    navigate({
      pathname: `/projectdashboard/${group.number}`,
      state: { group }
    });
    console.log('there')
  };

  return (
    <div className="group-list-container">
      <h2 className="group-list-header">Group List</h2>

      {groups.map((group, index) => (
        <div key={index} className="group-container" style={{cursor: 'pointer'}} onClick={() => handleGroupClick(group)}>
          <h3 className="group-header">Group {group.number}</h3>
          <p><strong>Supervisor:</strong> {group.supervisor.name}</p>
          <p><strong>Project Title:</strong> {group.projectTitle}</p>
          <ul>
            {group.members.map((student) => (
              <li key={student.rollNumber}>
                {student.name} ({student.rollNumber})
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

export default GroupList;
