import React, { useState, useEffect } from "react";
import "./Styles/StudentList.css";

function StudentList() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    const storedStudents = localStorage.getItem("students");
    if (storedStudents) {
      setStudents(JSON.parse(storedStudents));
    }
  }, []);

  return (
    <div className="student-list">
      <h2>Registered Students</h2>
      <ul>
        <li className="header">Name: Roll No</li>
        {students.map((student) => (
          <li key={student.rollNumber}>
            {student.name}: {student.rollNumber}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default StudentList;
