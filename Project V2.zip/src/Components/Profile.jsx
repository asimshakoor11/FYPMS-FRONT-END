import React, { useState, useEffect } from "react";
import "./Styles/Profile.css";

function Profile() {
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [photo, setPhoto] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const savedName = localStorage.getItem("name");
    const savedAddress = localStorage.getItem("address");
    const savedEmail = localStorage.getItem("email");
    const savedPhone = localStorage.getItem("phone");
    const savedPhoto = localStorage.getItem("photo");

    if (savedName) setName(savedName);
    if (savedAddress) setAddress(savedAddress);
    if (savedEmail) setEmail(savedEmail);
    if (savedPhone) setPhone(savedPhone);
    if (savedPhoto) setPhoto(savedPhoto);
  }, []);

  useEffect(() => {
    localStorage.setItem("name", name);
    localStorage.setItem("address", address);
    localStorage.setItem("email", email);
    localStorage.setItem("phone", phone);
    localStorage.setItem("photo", photo);
  }, [name, address, email, phone, photo]);

  const handleNameChange = (e) => setName(e.target.value);
  const handleAddressChange = (e) => setAddress(e.target.value);
  const handleEmailChange = (e) => setEmail(e.target.value);
  const handlePhoneChange = (e) => setPhone(e.target.value);
  const handlePhotoChange = (e) =>
    setPhoto(URL.createObjectURL(e.target.files[0]));
  const toggleEditing = () => setIsEditing(!isEditing);

  return (
    <div className="profile-container">
      <h1>Profile</h1>
      <div className="profile-grid">
        <div className="profile-photo-container">
          {photo && <img src={photo} alt="Profile" className="profile-photo" />}
        </div>
        <div className="profile-details">
          {isEditing ? (
            <>
              <label>Name:</label>
              <input type="text" value={name} onChange={handleNameChange} />
              <label>Address:</label>
              <input type="text" value={address} onChange={handleAddressChange} />
              <label>Email:</label>
              <input type="email" value={email} onChange={handleEmailChange} />
              <label>Phone Number:</label>
              <input type="tel" value={phone} onChange={handlePhoneChange} />
              <label>Photo:</label>
              <input type="file" onChange={handlePhotoChange} />
            </>
          ) : (
            <>
              <div className="profile-info">
                <label>Name:</label>
                <p>{name}</p>
                <label>Address:</label>
                <p>{address}</p>
                <label>Email:</label>
                <p>{email}</p>
                <label>Phone Number:</label>
                <p>{phone}</p>
              </div>
            </>
          )}
          <button onClick={toggleEditing}>
            {isEditing ? "Save Profile" : "Edit Profile"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Profile;
