import React, { useState, useEffect } from "react";

import "./Styles/StudentList.css";

const SupervisorsList = () => {
  const [supervisors, setSupervisors] = useState([]);

  useEffect(() => {
    const storedSupervisors = localStorage.getItem("supervisors");
    if (storedSupervisors) {
      setSupervisors(JSON.parse(storedSupervisors));
    }
  }, []);

  return (
    <div className="student-list">
      <h2>SuperVisors List</h2>
      <ul>
        {supervisors.map((supervisor) => (
          <li key={supervisor.rollNumber}>
            {supervisor.name} - {supervisor.id}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SupervisorsList;
