import React, { useState, useEffect } from "react";
import "./Styles/StudentReg.css";

function StudentReg() {
  const [name, setName] = useState("");
  const [rollNumber, setRollNumber] = useState("");
  const [students, setStudents] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const storedStudents = localStorage.getItem("students");
    if (storedStudents) {
      setStudents(JSON.parse(storedStudents));
    }
  }, []);

  const handleAddStudent = () => {
    if (name && rollNumber) {
      // Check if roll number already exists
      const existingStudent = students.find(student => student.rollNumber === rollNumber);
      if (existingStudent) {
        setError("Student with this roll number already exists.");
        return;
      }

      // If roll number is unique, add the student
      const newStudent = { name, rollNumber };
      const updatedStudents = [...students, newStudent];
      setStudents(updatedStudents);
      setName("");
      setRollNumber("");
      localStorage.setItem("students", JSON.stringify(updatedStudents));
      setError(""); // Clear any previous errors
    }
  };

  const handleDeleteStudent = (index) => {
    const newStudents = students.filter((_, i) => i !== index);
    setStudents(newStudents);
    localStorage.setItem("students", JSON.stringify(newStudents));
  };

  return (
    <div className="student-reg-container">
      <h1>Register Student</h1>
      <div className="input-container">
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Roll Number"
          value={rollNumber}
          onChange={(e) => {
            setRollNumber(e.target.value);
            setError(""); // Clear error message when roll number changes
          }}
        />
        <button onClick={handleAddStudent}>Add Student</button>
      </div>
      {error && <p className="error-message">{error}</p>}
      <ul className="students-list">
        {students.map((student, index) => (
          <li className="list-item" key={index}>
            <p>
              <b>Name:</b> {student.name} <br />
              <b>Roll No:</b> {student.rollNumber}
            </p>
            <button onClick={() => handleDeleteStudent(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default StudentReg;
