import React, { useState, useEffect } from "react";
import "./Styles/SupervisorReg.css";

function SupervisorReg() {
  const [name, setName] = useState("");
  const [id, setId] = useState("");
  const [supervisors, setSupervisors] = useState([]);

  useEffect(() => {
    const storedSupervisors = localStorage.getItem("supervisors");
    if (storedSupervisors) {
      setSupervisors(JSON.parse(storedSupervisors));
    }
  }, []);

  const handleAddSupervisor = () => {
    if (name && id) {
      const supervisorExists = supervisors.some(supervisor => supervisor.id === id);
      if (supervisorExists) {
        alert("Supervisor with this ID already exists.");
        return;
      }
      
      const newSupervisor = { name, id };
      const updatedSupervisors = [...supervisors, newSupervisor];
      setSupervisors(updatedSupervisors);
      localStorage.setItem("supervisors", JSON.stringify(updatedSupervisors));
      setName("");
      setId("");
    }
  };

  const handleDeleteSupervisor = (index) => {
    const newSupervisors = supervisors.filter((_, i) => i !== index);
    setSupervisors(newSupervisors);
    localStorage.setItem("supervisors", JSON.stringify(newSupervisors));
  };

  return (
    <div className="supervisor-reg-container">
      <h1>Register Supervisor</h1>
      <div className="input-container">
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="ID"
          value={id}
          onChange={(e) => setId(e.target.value)}
        />
        <button onClick={handleAddSupervisor}>Add Supervisor</button>
      </div>
      <ul className="supervisor-list">
        {supervisors.map((supervisor, index) => (
          <li className="list-item" key={index}>
            <p>
              <b>Name:</b> {supervisor.name} <br />
              <b>ID:</b> {supervisor.id}
            </p>
            <button onClick={() => handleDeleteSupervisor(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default SupervisorReg;
