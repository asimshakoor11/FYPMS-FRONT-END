import React, { useState, useEffect } from "react";
import { Link, useLocation, useParams } from "react-router-dom";
import "./Styles/CommitteDashboard.css";

function ProjectDashboard() {
  const location = useLocation();
  const { groupId } = useParams();
  const [role, setRole] = useState('');

  useEffect(() => {
    const storedRole = localStorage.getItem("userRole");
    if (storedRole) {
      setRole(storedRole);
    }
  }, []);

  // Load groups from local storage or initial state
  const initialGroups = JSON.parse(localStorage.getItem("groups")) || [];
  const [groups, setGroups] = useState(initialGroups);

  // Find the group by groupId
  const group = groups.find(g => g.number.toString() === groupId);

  useEffect(() => {
    // Update local storage whenever groups change
    localStorage.setItem("groups", JSON.stringify(groups));
  }, [groups]);

  const [selectedComponent, setSelectedComponent] = useState("Dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const closeSidebar = () => {
    if (isSidebarOpen) {
      setIsSidebarOpen(false);
    }
  };

  const handleUpdateMarks = (updatedMarks) => {
    const updatedGroup = {
      ...group,
      members: group.members.map(member => ({
        ...member,
        marks: updatedMarks[member.rollNumber] || member.marks
      }))
    };
    setGroups(groups.map(g => (g.number.toString() === groupId ? updatedGroup : g)));
  };

  const handleUpdateProgress = (progress) => {
    const updatedGroup = {
      ...group,
      progress
    };
    setGroups(groups.map(g => (g.number.toString() === groupId ? updatedGroup : g)));
  };

  return (
    <>
      <div className="fyp-dashboard" onClick={closeSidebar}>
        <button className="hamburger" onClick={(e) => { e.stopPropagation(); setIsSidebarOpen(!isSidebarOpen); }}>
          &#9776;
        </button>
        <div className={`sidebar ${isSidebarOpen ? 'open' : ''}`} onClick={(e) => e.stopPropagation()}>
          <div>
            <p className="Logoword">Project Dashboard</p>
          </div>
          <ul>
            {role === 'FYP Committee' ? (
              <>
                <li onClick={() => setSelectedComponent("Dashboard")}>Dashboard</li>
                <li onClick={() => setSelectedComponent("Update Marks")}>Update Marks</li>
                <Link to={'/CommitteeDashboard'} style={{ textDecoration: 'none', color: 'white' }}><li>Go Back</li></Link>
              </>
            ) : role === 'Supervisor' ? (
              <>
                <li onClick={() => setSelectedComponent("Dashboard")}>Dashboard</li>
                <li onClick={() => setSelectedComponent("Update Marks")}>Update Marks</li>
                <li onClick={() => setSelectedComponent("Update Progress")}>Update Progress</li>
                <li onClick={() => setSelectedComponent("Update Tasks")}>Update Tasks</li>
                <li onClick={() => setSelectedComponent("View Submissions")}>View Submissions</li>
                <Link to={'/SuperDashboard'} style={{ textDecoration: 'none', color: 'white' }}><li>Go Back</li></Link>
              </>
            ) : role === 'Student' ? (
              <>
                <li onClick={() => setSelectedComponent("Dashboard")}>Dashboard</li>
                <li onClick={() => setSelectedComponent("View Tasks")}>View Tasks</li>
                <li onClick={() => setSelectedComponent("Submit Tasks")}>Submit Tasks</li>
                <Link to={'/StudentDashboard'} style={{ textDecoration: 'none', color: 'white' }}><li>Go Back</li></Link>
              </>
            ) : (
              <li>No options available</li>
            )}
          </ul>
        </div>
        {isSidebarOpen && <div className="overlay" onClick={closeSidebar}></div>}
        <div className="content">
          {selectedComponent === 'Dashboard' && (
            <div>
              <h2>Group {group.number}</h2>
              <p><strong>Supervisor:</strong> {group.supervisor.name}</p>
              <p><strong>Project Title:</strong> {group.projectTitle}</p>
              <h3>Members</h3>
              <ul>
                {group.members.map((student) => (
                  <li key={student.rollNumber}>
                    {student.name} ({student.rollNumber}) - Marks: {student.marks}
                  </li>
                ))}
              </ul>
              <h3>Project Phase</h3>
              <p>Literature Review</p>
              <h3>Project Progress</h3>
              <p>{group.progress || 'Not updated yet'}</p>
            </div>
          )}
          {selectedComponent === 'Update Marks' && (
            <div>
              <h2>Update Marks</h2>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const updatedMarks = {};
                formData.forEach((value, key) => {
                  updatedMarks[key] = parseInt(value);
                });
                handleUpdateMarks(updatedMarks);
              }}>
                {group.members.map((student) => (
                  <div key={student.rollNumber}>
                    <label>
                      {student.name} ({student.rollNumber}):{" "}
                      <input type="number" name={student.rollNumber} defaultValue={student.marks} />
                    </label>
                    <br />
                  </div>
                ))}
                <button type="submit">Save Marks</button>
              </form>
            </div>
          )}
          {selectedComponent === 'Update Progress' && (
            <div>
              <h2>Update Progress</h2>
              <form onSubmit={(e) => {
                e.preventDefault();
                const progress = e.target.elements.progress.value;
                handleUpdateProgress(progress);
              }}>
                <label>
                  Progress:
                  <input type="text" name="progress" defaultValue={group.progress} />
                </label>
                <button type="submit">Save Progress</button>
              </form>
            </div>
          )}
          {selectedComponent === 'Update Tasks' && (
            <div>
              <h2>Update Tasks</h2>
              {/* Add content for updating tasks */}
              <p>Form to update tasks will be here.</p>
            </div>
          )}
          {selectedComponent === 'View Submissions' && (
            <div>
              <h2>View Submissions</h2>
              {/* Add content for viewing submissions */}
              <p>List of submissions will be displayed here.</p>
            </div>
          )}
          {selectedComponent === 'Submit Tasks' && (
            <div>
              <h2>Submit Tasks</h2>
              {/* Add content for submitting tasks */}
              <p>Form to submit tasks will be here.</p>
            </div>
          )}
          {selectedComponent === 'View Tasks' && (
            <div>
              <h2>View Tasks</h2>
              {/* Add content for viewing tasks */}
              <p>List of tasks will be displayed here.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default ProjectDashboard;
